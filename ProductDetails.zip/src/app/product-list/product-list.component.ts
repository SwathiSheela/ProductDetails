import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  constructor(private httpClient: HttpClient) { }
public productList: any;

  ngOnInit(): void {
    const headers = new HttpHeaders()
    .append('api-key', 'API-O8RVKWL4GIFMSEV');
    headers.append('accept','text/plain')
const params = new HttpParams()
    this.httpClient.get('/api/Products',{headers,params}).subscribe(
      list=>{
        if(list){
          this.productList=list;
        }
      },
      error=>{
        console.error('Error',error);
      })
  }

}
